package main

import (
	"fmt"
	"math"
)

// challenge 7 day 2
func main() {
	var input int
	fmt.Println("Input nilai:")
	fmt.Scanln(&input)
	fmt.Printf("Faktor dari %d\n", input)
	absolute := math.Abs(float64(input))
	for i := 1; i <= int(absolute); i++ {
		if input%i == 0 && input > 0 {
			fmt.Println(i)
		} else if input%i == 0 && input < 0 {
			fmt.Println(i)
			fmt.Println(i * -1)
		}
	}

}
