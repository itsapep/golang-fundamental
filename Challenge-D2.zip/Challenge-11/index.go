package main

import "fmt"

// challenge 8 day 2
func main() {
	var input string
	fmt.Println("Pemeriksa Kata Palindrom")
	fmt.Println("Input kata:")
	fmt.Scanln(&input)
	// var reverse string =""
	// for i:=len(str)-1;i>=0;i++{
	// 	reverse=reverse+str[i]
	// }
	// fmt.Println(reverse)
	var reverse string
	for _, v := range input {
		reverse = string(v) + reverse
	}
	if reverse == input {
		fmt.Println(input, "=", reverse)
		fmt.Println("Kata ini termasuk palindrom")
	} else {
		fmt.Printf("%s ≠ %s\n", input, reverse)
		fmt.Println("Kata ini bukan palindrom")
	}
}
