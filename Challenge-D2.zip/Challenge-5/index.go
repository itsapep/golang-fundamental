package main

import "fmt"

// challenge 2 day 2
func main() {
	var tugas, uts, uas float32

	fmt.Println("Input nilai tugas:")
	fmt.Scanln(&tugas)
	fmt.Println("Input nilai UTS:")
	fmt.Scanln(&uts)
	fmt.Println("Input nilai UAS:")
	fmt.Scanln(&uas)

	if total := (tugas * 25 / 100) + (uts * 30 / 100) + (uas * 45 / 100); total >= 80 {
		fmt.Printf("nilai %.2f dengan hasil akhir adalah A", total)
	} else if total >= 70 {
		fmt.Printf("nilai %.2f dengan hasil akhir adalah B", total)
	} else if total >= 55 {
		fmt.Printf("nilai %.2f dengan hasil akhir adalah C", total)
	} else if total >= 40 {
		fmt.Printf("nilai %.2f dengan hasil akhir adalah D", total)
	} else if total > 100 || total < 0 {
		fmt.Println("nilai tidak valid (range 0-100)")
	} else {
		fmt.Printf("nilai %.2f dengan hasil akhir adalah E", total)
	}
}
