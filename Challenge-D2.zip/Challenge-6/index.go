package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

func main() {
	// var nama, peran string
	inputReader := bufio.NewScanner(os.Stdin)

	fmt.Println("Masukkan nama anda:")
	inputReader.Scan()
	nama := inputReader.Text()
	fmt.Println("tuliskan peran anda (superhero/monster?):")
	inputReader.Scan()
	x := inputReader.Text()
	peran := strings.ToLower(x)

	if nama == "" && peran == "" {
		fmt.Println("Nama dan Peran Harus Diisi")
	} else if peran == "" {
		fmt.Println("Peran Harus Diisi")
	} else {
		if peran == "superhero" {
			fmt.Printf("Selamat Datang Superhero Saitama a.k.a %s, Kalahkan Semua Monster Di Muka Bumi", nama)
		} else if peran == "monster" {
			fmt.Printf("Selamat Datang Monster Saitama a.k.a %s, Hancurkan Semua Superhero Yang Ada", nama)
		} else {
			fmt.Printf("Selamat Datang Saitama a.k.a %s, Pilih Peranmu Untuk Melanjutkan Game Ini", nama)
		}
	}
}
