package main

import (
	"fmt"
	"strconv"
)

// challenge 1 day 2
func main() {
	var (
		input string
		jam   int
	)

	fmt.Println("jam berapa sekarang?")
	fmt.Scanln(&input)

	_, err := fmt.Scan(&input)
	jam, err = strconv.Atoi(input)
	if err != nil {
		fmt.Println("Enter a valid number")
	} else if jam == 4 || jam == 5 {
		fmt.Println("bangun pagi")
	} else if jam == 6 || jam == 7 {
		fmt.Println("Mandi dan Sarapan")
	} else if jam >= 8 && jam <= 11 {
		fmt.Println("Berangkat Sekolah")
	} else if jam == 12 {
		fmt.Println("Pulang Sekolah")
	} else if jam >= 13 && jam <= 15 {
		fmt.Println("Tidur Siang")
	} else if jam == 16 || jam == 17 {
		fmt.Println("Waktu Main")
	} else if jam > 24 || jam < 0 {
		fmt.Println("hanya ada 24 jam dalam sehari!")
	} else {
		fmt.Println("Waktu Belajar dan Istirahat")
	}
}
