package main

import "fmt"

// challenge 6 day 2
func main() {
	var input int
	fmt.Println("Input nilai:")
	fmt.Scanln(&input)
	if input < 0 {
		fmt.Println("masukkan bilangan bulat positif!")
	} else {
		fmt.Printf("Penjumlahan bilangan ganjil yang kurang dari %d\n", input)
		jmlGanjil, jmlGenap := 0, 0
		for i := 1; i < input; i++ {
			if i%2 != 0 {
				fmt.Print(i)
				jmlGanjil += i
			} else if jmlGanjil > input {
				break
			} else if i != input-1 {
				fmt.Print(" + ")
			}

		}
		fmt.Println(" =", jmlGanjil)

		fmt.Printf("Penjumlahan %d bilangan genap pertama\n", input)
		i := 2
		for input != 0 {
			if i%2 == 0 {
				fmt.Print(i)
				jmlGenap += i
				input--
			} else {
				fmt.Print(" + ")
			}
			i++
		}
		fmt.Println(" =", jmlGenap)
	}

}
