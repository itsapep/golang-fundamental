package main

import "fmt"

// challenge 5 day 2
func main() {
	var input int
	fmt.Println("Input perulangan:")
	fmt.Scanln(&input)
	if input < 0 {
		fmt.Println("masukkan bilangan bulat positif!")
	} else {
		fmt.Printf("Mengulang sebanyak %d kali\n", input)
		for i := input; i != 0; i-- {
			fmt.Println(i, "- saya programmer golang")
		}
	}
}
