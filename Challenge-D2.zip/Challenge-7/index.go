package main

import "fmt"

// challenge 4 day 2
func main() {
	var (
		tanggal, bln, tahun int
		bulan               interface{}
	)
	fmt.Println("Input tanggal:")
	fmt.Scanln(&tanggal)
	fmt.Println("Input bulan:")
	fmt.Scanln(&bln)
	fmt.Println("Input tahun:")
	fmt.Scanln(&tahun)

	if tanggal == 0 || bln == 0 || tahun == 0 {
		fmt.Println("Tanggal, Bulan, dan Tahun Harus Diisi")
	} else if tanggal < 1 || tanggal > 31 {
		fmt.Println("Tanggal tidak valid")
	} else if bln == 2 {
		if tanggal > 28 {
			fmt.Println("Februari maksimal 28 hari!")
		} else if tanggal == 28 && tahun%4 != 0 {
			fmt.Println("Bukan tahun kabisat")
		}
	} else {
		switch bln {
		case 2, 4, 6, 8, 9, 11:
			if tanggal == 31 {
				fmt.Printf("pada bulan %d tanggal maksimal 30!\n", bln)
			}
		default:
			break
		}
	}

	switch bln {
	case 1:
		bulan = "Januari"
	case 2:
		bulan = "Februari"
	case 3:
		bulan = "Maret"
	case 4:
		bulan = "April"
	case 5:
		bulan = "Mei"
	case 6:
		bulan = "Juni"
	case 7:
		bulan = "Juli"
	case 8:
		bulan = "Agustus"
	case 9:
		bulan = "September"
	case 10:
		bulan = "Oktober"
	case 11:
		bulan = "November"
	case 12:
		bulan = "Desember"
	default:
		fmt.Println("Bulan tidak valid (1-12)")
	}

	fmt.Printf("Tanggal yang dimasukkan: %d %s %d\n", tanggal, bulan, tahun)
}
